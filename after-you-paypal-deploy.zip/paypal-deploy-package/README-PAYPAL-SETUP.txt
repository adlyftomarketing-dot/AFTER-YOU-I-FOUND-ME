AFTER YOU, I FOUND ME — PAYPAL + CLOUDFLARE PAGES SETUP

This package includes the vintage/cinematic website, PayPal JavaScript SDK v6 checkout wiring, Cloudflare Pages Functions, and your PDF. The PDF must be stored in a PRIVATE Cloudflare R2 bucket, not in the public website folder.

IMPORTANT
- The checkout is NOT live until you add your own PayPal LIVE Client ID and Cloudflare secrets/binding.
- Never send or paste your PayPal Client Secret in chat, HTML, or a public file.
- The site price is fixed server-side at USD 3.99. Payment capture is checked server-side before the PDF is returned.

A) PAYPAL DEVELOPER APP
1. Open https://developer.paypal.com/dashboard/applications
2. Sign in with your PayPal Business account.
3. Open Apps & Credentials; select Live (not Sandbox).
4. Create an app, e.g. After You I Found Me Store.
5. Copy the LIVE Client ID. Keep the LIVE Secret private.
6. Add the exact published website domain to any PayPal domain/website settings if prompted.
7. Confirm your PayPal India account has completed email and identity confirmation and can receive international payments.

B) CLOUDFLARE R2 PRIVATE PDF STORAGE
1. Cloudflare Dashboard > R2 Object Storage > Create bucket (e.g. after-you-private-books).
2. Upload the included book.pdf into the bucket with the exact object key: book.pdf
3. Do NOT enable public access or use an r2.dev public URL.
4. Open Workers & Pages > your Pages project > Settings > Bindings > Add > R2 bucket.
5. Variable name: BOOK_FILES. Select the bucket you created. Save.

C) CLOUDFLARE SECRETS
In your Pages project: Settings > Variables and Secrets > Add:
- PAYPAL_CLIENT_ID = your LIVE Client ID (plain environment variable is okay, though keep it private in dashboard)
- PAYPAL_CLIENT_SECRET = your LIVE Secret (select Encrypt / Secret)
- PAYPAL_MODE = live
Redeploy the project after adding the bindings/secrets.

D) PUBLIC CLIENT ID IN THE WEBSITE
Open index.html and replace:
PASTE_YOUR_PAYPAL_LIVE_CLIENT_ID_HERE
with the LIVE Client ID from PayPal. Client ID is public by design; never put the Secret here.

E) DEPLOY
Deploy the whole project folder (the folder containing index.html and functions/) to Cloudflare Pages using Git integration or Wrangler. If using Direct Upload, ensure your Pages upload workflow supports Pages Functions; otherwise connect a Git repository or use Wrangler Pages deployment. Do not upload only index.html.

F) TEST BEFORE LAUNCH
Prefer a separate Sandbox app and Sandbox credentials for testing first. Use a Sandbox buyer account to test the whole purchase and download flow. Only switch to Live after testing. Do not use a real payment to test.

PROJECT FILES
- index.html: storefront and PayPal JS SDK v6 button
- functions/api/create-order.js: creates a fixed USD 3.99 PayPal order server-side
- functions/api/capture-order.js: captures and validates completed USD 3.99 payment, then streams the private PDF from R2
- book.pdf: upload this to private R2 as book.pdf; do not leave it in the public root when deploying
- assets/book-cover.png: public cover image

SUPPORT / BUSINESS CHECKLIST
Add a real contact email and publish Privacy Policy, Terms, and Refund Policy before accepting customers. Confirm the digital product description and relevant PayPal account/business purpose details are accurate.
