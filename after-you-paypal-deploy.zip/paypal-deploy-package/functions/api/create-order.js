export async function onRequestPost({ env }) {
  try {
    const token = await getAccessToken(env);
    const response = await fetch(`${apiBase(env)}/v2/checkout/orders`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "PayPal-Request-Id": crypto.randomUUID() },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{
          description: "After You, I Found Me — Digital E-book",
          amount: { currency_code: "USD", value: "3.99" },
          items: [{ name: "After You, I Found Me (Digital E-book)", quantity: "1", unit_amount: { currency_code: "USD", value: "3.99" }, category: "DIGITAL_GOODS" }]
        }]
      })
    });
    const data = await response.json();
    if (!response.ok || !data.id) return json({ error: "PayPal could not create the order." }, 502);
    return json({ id: data.id });
  } catch (error) {
    return json({ error: "Payment service is not configured correctly." }, 500);
  }
}

async function getAccessToken(env) {
  const basic = btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`);
  const response = await fetch(`${apiBase(env)}/v1/oauth2/token`, {
    method: "POST", headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" }, body: "grant_type=client_credentials"
  });
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error("PayPal authentication failed");
  return data.access_token;
}
function apiBase(env) { return env.PAYPAL_MODE === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com"; }
function json(data, status=200) { return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } }); }
