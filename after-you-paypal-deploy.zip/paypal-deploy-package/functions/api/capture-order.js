export async function onRequestPost({ request, env }) {
  try {
    const { orderId } = await request.json();
    if (typeof orderId !== "string" || !/^[A-Z0-9-]{8,80}$/i.test(orderId)) return json({ error: "Invalid order." }, 400);
    const token = await getAccessToken(env);
    const response = await fetch(`${apiBase(env)}/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`, {
      method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "PayPal-Request-Id": `capture-${orderId}` }
    });
    const data = await response.json();
    if (!response.ok || data.status !== "COMPLETED") return json({ error: "Payment has not been completed." }, 402);
    const unit = data.purchase_units?.[0];
    const capture = unit?.payments?.captures?.[0];
    if (capture?.status !== "COMPLETED" || capture?.amount?.currency_code !== "USD" || capture?.amount?.value !== "3.99") {
      return json({ error: "Payment details could not be verified." }, 402);
    }
    const book = await env.BOOK_FILES.get("book.pdf");
    if (!book) return json({ error: "The e-book file is not installed in secure storage yet." }, 503);
    const headers = new Headers();
    book.writeHttpMetadata(headers);
    headers.set("Content-Type", "application/pdf");
    headers.set("Content-Disposition", 'attachment; filename="After-You-I-Found-Me.pdf"');
    headers.set("Cache-Control", "private, no-store");
    return new Response(book.body, { status: 200, headers });
  } catch (error) {
    return json({ error: "Could not verify payment. Please contact support if you were charged." }, 500);
  }
}
async function getAccessToken(env) {
  const basic = btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`);
  const response = await fetch(`${apiBase(env)}/v1/oauth2/token`, { method: "POST", headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" }, body: "grant_type=client_credentials" });
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error("PayPal authentication failed");
  return data.access_token;
}
function apiBase(env) { return env.PAYPAL_MODE === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com"; }
function json(data, status=200) { return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } }); }
